package com.example.servermonitor;

import org.junit.Test;

public class ExampleTest {
    @Test
    public void onStart() {
    }
}
