package com.example.servermonitor.provider;

import com.example.servermonitor.ResourceTable;
import com.example.servermonitor.fsItem;
import ohos.aafwk.ability.AbilitySlice;
import ohos.agp.components.*;

import java.util.List;

public class fsItemProvider extends BaseItemProvider {
    private List<fsItem> list;
    private AbilitySlice slice;

    //构造函数
    public fsItemProvider(List<fsItem> list,AbilitySlice slice) {
        this.list = list;
        this.slice =slice;
    }

    @Override
    //返回填充的表项个数
    public int getCount() {
        return list == null ? 0 : list.size();
    }

    @Override
    //根据position返回对应的数据
    public Object getItem(int position) {
        if (list != null && position >= 0 && position < list.size()){
            return list.get(position);
        }
        return null;
    }

    @Override
    //返回某一项的id
    public long getItemId(int position) {
        //
        return position;
    }

    @Override
    //根据position返回对应的界面组件
    public Component getComponent(int position, Component convertComponent, ComponentContainer componentContainer) {
        final Component cpt;
        if (convertComponent == null) {
            cpt = LayoutScatter.getInstance(slice).parse(ResourceTable.Layout_item_fs_list, null, false);
        } else {
            cpt = convertComponent;
        }
        fsItem fsItem = list.get(position);
        Text item_device_name = (Text) cpt.findComponentById(ResourceTable.Id_item_device_name);
        Text item_fs_type = (Text) cpt.findComponentById(ResourceTable.Id_item_fs_type);
        Text item_size = (Text) cpt.findComponentById(ResourceTable.Id_item_size);
        Text item_free = (Text) cpt.findComponentById(ResourceTable.Id_item_free);
        Text item_percent = (Text) cpt.findComponentById(ResourceTable.Id_item_percent);
        item_device_name.setText(fsItem.getName());
        item_fs_type.setText(fsItem.getType());
        item_size.setText(fsItem.getSize());
        item_free.setText(fsItem.getFree());
        item_percent.setText(fsItem.getPercent());
        return cpt;
    }
}
