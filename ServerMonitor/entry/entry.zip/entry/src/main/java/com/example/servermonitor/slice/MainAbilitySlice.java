package com.example.servermonitor.slice;

import Constant.Constant;
import com.example.servermonitor.ProcessItem;
import com.example.servermonitor.ResourceTable;
import com.example.servermonitor.ServerItem;
import com.example.servermonitor.provider.ServerItemProvider;
import ohos.aafwk.ability.AbilitySlice;
import ohos.aafwk.ability.IAbilityConnection;
import ohos.aafwk.content.Intent;
import ohos.aafwk.content.Operation;
import ohos.agp.components.*;
import ohos.agp.utils.LayoutAlignment;
import ohos.agp.window.dialog.CommonDialog;
import ohos.agp.window.dialog.IDialog;
import ohos.agp.window.dialog.ToastDialog;
import ohos.ai.cv.text.Text;
import ohos.bundle.ElementName;
import ohos.hiviewdfx.HiLog;
import ohos.hiviewdfx.HiLogLabel;
import ohos.rpc.*;
import ohos.utils.zson.ZSONObject;
import org.json.JSONObject;
import utils.NetDownLoadUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import static ohos.agp.components.ComponentContainer.LayoutConfig.MATCH_CONTENT;
import static ohos.agp.components.ComponentContainer.LayoutConfig.MATCH_PARENT;

public class MainAbilitySlice extends AbilitySlice {

    DirectionalLayout toastLayout;
    //主页面组件
    TextField input_server_ip;
    Button btn_add_server;
    ListContainer listContainer;
    ServerItemProvider serverItemProvider;
    private static final HiLogLabel LABEL_LOG = new HiLogLabel(3, 0x00201, "MainAbilitySlice");

    private static final String BUNDLE_NAME = "com.example.servermonitor";
    private static final String SERVICE_NAME = "ServiceAbility";
    private ClientRemoteProxy clientRemoteProxy = null;

    //创建IAbilityConnection类型连接对象
    private IAbilityConnection connection = new IAbilityConnection() {
        @Override
        public void onAbilityConnectDone(ElementName elementName, IRemoteObject iRemoteObject, int i) {
            clientRemoteProxy = new ClientRemoteProxy(iRemoteObject);
        }

        @Override
        public void onAbilityDisconnectDone(ElementName elementName, int resultCode) {
            HiLog.info(LABEL_LOG, "%{public}s", "onAbilityDisconnectDone resultCode : " + resultCode);
        }
    };

    // 客户端代理类
    public class ClientRemoteProxy implements IRemoteBroker {
        private static final int RESULT_SUCCESS = 0;
        private final IRemoteObject remoteObject;

        public ClientRemoteProxy(IRemoteObject remoteObject) {
            this.remoteObject = remoteObject;
        }

        // 在此方法发送请求消息！！！！！！！！
        // 通过服务器ip获取状态信息
        public void todoServiceJob(ServerItem selected_item,String IP) {
            //传出参数
            MessageParcel message = MessageParcel.obtain();
            HiLog.info(LABEL_LOG, "Request_ip------> " + IP);
            message.writeString(IP);
            //接收传回参数
            MessageParcel reply = MessageParcel.obtain();
            // 异步or同步
            MessageOption option = new MessageOption(MessageOption.TF_SYNC); //TF_SYNC表示同步，TF_ASYNC表示异步

            try {
                // 发送请求
                HiLog.info(LABEL_LOG, "sendRequest------ ");
                remoteObject.sendRequest(1, message, reply, option);

                //处理返回结果................
                //..........................
                int result = reply.readInt();
                if(result == Constant.FAIL){
                    new ToastDialog(getContext()).setText("查询服务器状态失败！请检查ip地址或更换服务器。").setAlignment(LayoutAlignment.CENTER).show();
                }
                else if (result == Constant.SUCCESS){
                    String cpuData = reply.readString();
                    HiLog.info(LABEL_LOG, "cpuData------>" + cpuData);
                    String memData = reply.readString();
                    HiLog.info(LABEL_LOG, "memData------>" + memData);
                    String processData = reply.readString();
                    HiLog.info(LABEL_LOG, "processData------>" + processData);
                    String sysData = reply.readString();
                    HiLog.info(LABEL_LOG, "sysData------->" + sysData);
                    String fsData = reply.readString();
                    HiLog.info(LABEL_LOG,"fsData-------->"+fsData);

                    JSONObject sysJSONObject = new JSONObject(sysData);
                    String s_name = sysJSONObject.optString("hostname");
                    selected_item.setName(s_name); //更新服务器名
                    //List<Map> list = ZSONArray.stringToClassList(processData, Map.class);

                    //Intent传值
                    Intent intent =new Intent();
                    intent.setParam("server_name",s_name);
                    intent.setParam("server_ip",item.getIp());
                    intent.setParam("cpu_data",cpuData);
                    intent.setParam("mem_data",memData);
                    intent.setParam("process_data",processData); //此processData为JSON格式
                    intent.setParam("sys_data",sysData);
                    intent.setParam("fs_data",fsData);

                    present(new DetailAbilitySlice(),intent);  //带值跳转页面
                }

            } catch (RemoteException e) {
                e.printStackTrace();
            }
        }

        @Override
        public IRemoteObject asObject() {
            return remoteObject;
        }
    }

    @Override
    public void onStart(Intent intent) {
        super.onStart(intent);
        super.setUIContent(ResourceTable.Layout_ability_main);
        HiLog.info(LABEL_LOG, "connectService------ ");
        // 连接服务
        connectAbility(getServiceIntent(BUNDLE_NAME, SERVICE_NAME), connection);
        initComponent();
        initListContainer();
        initListener();
    }

    //获取启动本地服务的Intent
    //获取链接Service的Intent
    private Intent getServiceIntent(String bundleName,String serviceName){
        Operation operation = new Intent.OperationBuilder().withDeviceId("")
                .withBundleName(bundleName)
                .withAbilityName(serviceName)
                .build();
        Intent intent = new Intent();
        intent.setOperation(operation);
        return intent;
    }

    ServerItem item;
    //为每个ServerItem设置一个监听，点击某一项可跳转至详情页面
    private void initListener() {
        listContainer.setItemClickedListener((container, component, position, id) -> {
            item = (ServerItem) listContainer.getItemProvider().getItem(position);
            /*
            Operation operation =
                    new Intent.OperationBuilder()
                            .withBundleName(getBundleName())
                            .withAbilityName(DetailAbilitySlice.class.getName())
                            .withAction("action.detail")
                            .build();
            intent.setOperation(operation);
            */
            //添加代码将服务器详细信息以及进程列表信息传递给详情页面 ！！！！！！！！！
            clientRemoteProxy.todoServiceJob(item,item.getIp());
        });
        //长按删除ServerItem
        listContainer.setItemLongClickedListener((container, component, position, id) -> {
            item = (ServerItem) listContainer.getItemProvider().getItem(position);

            //对话框
            CommonDialog dialog = new CommonDialog(getContext());
            dialog.setTitleText("Notification");
            dialog.setContentText("确认删除此服务器？");
            dialog.setSize(MATCH_PARENT, MATCH_CONTENT);
            dialog.setAlignment(LayoutAlignment.CENTER);
            dialog.setAutoClosable(true);
            dialog.setButton(IDialog.BUTTON2, "确认", (iDialog, i) -> delete_server_item(dialog));
            dialog.setButton(IDialog.BUTTON3, "取消", (iDialog, i) -> iDialog.remove());
            dialog.setDestroyedListener(() -> {
                // TODO: 销毁后需要执行的任务。
            });
            dialog.show();
            return false;
        });
    }

    private void delete_server_item(CommonDialog dialog) {
        ServerItem serverItem = item;
        serverItemProvider.delete(serverItem); //调用自定义的delete方法以更新、删除serverItemProvider里的数据
        listContainer.setItemProvider(serverItemProvider);
        dialog.remove();
    }

    //初始化组件
    private void initComponent(){
        toastLayout = (DirectionalLayout) LayoutScatter.getInstance(this)
                .parse(ResourceTable.Layout_toast, null, false);
        input_server_ip = (TextField) findComponentById(ResourceTable.Id_input_server_ip);
        btn_add_server = (Button) findComponentById(ResourceTable.Id_btn_add_server);
        //初始化ListContainer
        listContainer = (ListContainer) findComponentById(ResourceTable.Id_server_list_container);
        //为添加按钮设置监听器
        btn_add_server.setClickedListener(component -> addServer());
    }

    //添加服务器
    private void addServer(){
        String server_ip = input_server_ip.getText();
        if (server_ip.length()>0){
            //需要连接服务器，能连上则添加至列表，添加代码继续判断！！！！
            HiLog.info(LABEL_LOG,"server_ip "+server_ip);

            //根据ip获得hostname
            String serverName = getServerName(server_ip);

            ServerItem serverItem = new ServerItem(serverName, server_ip);
            serverItemProvider.updata(serverItem); //调用自定义的update方法以更新serverItemProvider里的数据
            listContainer.setItemProvider(serverItemProvider);
            //消息提示
            input_server_ip.setText("");
            new ToastDialog(this)
                    .setContentCustomComponent(toastLayout)
                    .setSize(DirectionalLayout.LayoutConfig.MATCH_CONTENT, DirectionalLayout.LayoutConfig.MATCH_CONTENT)
                    // Toast显示在界面中间
                    .setAlignment(LayoutAlignment.CENTER)
                    .show();
        }
    }

    //通过ip获取服务器名称
    private String getServerName(String ip) {
        return "SERVER";
    }

    //初始化listContainer数据，即可以预置服务器在列表当中
    private void initListContainer() {
        List<ServerItem> list = getData();
        serverItemProvider = new ServerItemProvider(list, this);
        listContainer.setItemProvider(serverItemProvider);
        //list.add(new ServerItem("Server_Item" + serverItemProvider.getCount()));
        listContainer.setBindStateChangedListener(new Component.BindStateChangedListener() {
            @Override
            public void onComponentBoundToWindow(Component component) {
                // ListContainer初始化时数据统一在provider中创建，不直接调用这个接口；
                // 建议在onComponentBoundToWindow监听或者其他事件监听中调用。
                serverItemProvider.notifyDataChanged();
            }
            @Override
            public void onComponentUnboundFromWindow(Component component) {}
        });
    }
    //初始化数据，用list集合存放ServerItem
    //预置服务器 !!!!!!!!!!!!!
    //...
    private ArrayList<ServerItem> getData() {
        ArrayList<ServerItem> list = new ArrayList<>();
        for (int i = 0; i <= 1; i++) {
            list.add(new ServerItem("item_server" + i+"（测试用）","localhost"));
        }
        list.add(new ServerItem("item_server" +"（测试用）","10.8.109.151"));
        return list;
    }

    @Override
    public void onActive() {
        super.onActive();
    }

    @Override
    public void onForeground(Intent intent) {
        super.onForeground(intent);
    }
}
