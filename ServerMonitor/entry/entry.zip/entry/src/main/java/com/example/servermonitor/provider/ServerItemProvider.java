package com.example.servermonitor.provider;

import com.example.servermonitor.ProcessItem;
import com.example.servermonitor.ResourceTable;
import com.example.servermonitor.ServerItem;
import ohos.aafwk.ability.AbilitySlice;
import ohos.agp.components.*;

import java.util.List;

public class ServerItemProvider extends BaseItemProvider {
    private List<ServerItem> list;
    private AbilitySlice slice;

    //构造函数
    public ServerItemProvider(List<ServerItem> list,AbilitySlice slice) {
        this.list = list;
        this.slice =slice;
    }

    public void updata(ServerItem serverItem){
        this.list.add(serverItem);
    }
    public void delete(ServerItem serverItem){
        this.list.remove(serverItem);
    }

    @Override
    //返回填充的表项个数
    public int getCount() {
        return list == null ? 0 : list.size();
    }

    @Override
    //根据position返回对应的数据
    public Object getItem(int position) {
        if (list != null && position >= 0 && position < list.size()){
            return list.get(position);
        }
        return null;
    }

    @Override
    //返回某一项的id
    public long getItemId(int position) {
        //
        return position;
    }

    @Override
    //根据position返回对应的界面组件
    public Component getComponent(int position, Component convertComponent, ComponentContainer componentContainer) {
        final Component cpt;
        if (convertComponent == null) {
            cpt = LayoutScatter.getInstance(slice).parse(ResourceTable.Layout_item_server_list, null, false);
        } else {
            cpt = convertComponent;
        }
        ServerItem serverItem = list.get(position);
        Text item_server_name = (Text) cpt.findComponentById(ResourceTable.Id_item_server_name);
        Text item_server_ip = (Text) cpt.findComponentById(ResourceTable.Id_item_server_ip);
        item_server_name.setText(serverItem.getName());
        item_server_ip.setText(serverItem.getIp());
        return cpt;
    }
}
