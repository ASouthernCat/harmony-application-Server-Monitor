package com.example.servermonitor.slice;

import Constant.Constant;
import com.example.servermonitor.ProcessItem;
import com.example.servermonitor.ResourceTable;
import com.example.servermonitor.provider.ProcessItemProvider;
import ohos.aafwk.ability.AbilitySlice;
import ohos.aafwk.content.Intent;
import ohos.agp.components.Button;
import ohos.agp.components.Component;
import ohos.agp.components.ListContainer;
import ohos.agp.components.Text;
import ohos.agp.utils.LayoutAlignment;
import ohos.agp.window.dialog.ToastDialog;
import ohos.global.resource.Resource;
import ohos.hiviewdfx.HiLog;
import ohos.hiviewdfx.HiLogLabel;
import ohos.utils.zson.ZSONArray;
import ohos.utils.zson.ZSONObject;
import org.json.JSONObject;
import utils.JsonUtils;
import utils.NetDownLoadUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class DetailAbilitySlice extends AbilitySlice {
    Text txt_ip;
    Text txt_server_name;
    Text txt_CPU;
    Text txt_inner_mem;
    Button btn_more_info;

    String server_name = null,CPU ="0",ip =null,mem ="0",process_data=null,sys_data,fs_data;

    private static final HiLogLabel LABEL_LOG = new HiLogLabel(3, 0x00201, "DetailAbilitySlice");


    public void onStart(Intent intent) {
        super.onStart(intent);
        super.setUIContent(ResourceTable.Layout_server_details);
        //获取intent值
        //考虑添加一个方法，用intent传过来的ip获取processlist信息，并展示在列表中
        //...
        if(intent!=null){
            server_name = intent.getStringParam("server_name");
            ip = intent.getStringParam("server_ip");
            CPU = intent.getStringParam("cpu_data");
            mem = intent.getStringParam("mem_data");
            process_data  =intent.getStringParam("process_data");  //还需进一步解析以呈现至UI
            sys_data = intent.getStringParam("sys_data");
            fs_data = intent.getStringParam("fs_data");
        }

        txt_server_name = (Text) findComponentById(ResourceTable.Id_txt_server_name);
        txt_CPU = (Text) findComponentById(ResourceTable.Id_txt_CPU);
        txt_inner_mem = (Text) findComponentById(ResourceTable.Id_txt_inner_mem);
        btn_more_info = (Button) findComponentById(ResourceTable.Id_btn_more_info);
        btn_more_info.setClickedListener(component -> moreInfo());
        txt_ip = (Text) findComponentById(ResourceTable.Id_txt_ip) ;

        initListContainer();
        setUI();

        double x =Double.parseDouble(mem);
        //HiLog.info(LABEL_LOG,"x: "+x);
        if(x>80) {
            new ToastDialog(this)
                    .setContentText("内存占用率过高！")
                    .setTitleText("warning:")
                    .setAlignment(LayoutAlignment.TOP)
                    .setOffset(0,600)
                    .setDuration(8000)
                    .show();
        }

    }

    private void moreInfo() {
        JSONObject sysjSONObject = new JSONObject(sys_data);

        //解析
        String os_name = sysjSONObject.optString("os_name");   //操作系统
        String platform = sysjSONObject.optString("platform"); //系统位数
        //传值
        Intent intent = new Intent();
        intent.setParam("server_name",txt_server_name.getText());
        intent.setParam("server_ip",ip);
        intent.setParam("os_name",os_name);
        intent.setParam("platform",platform);
        intent.setParam("fs",fs_data);
        //跳转
        present(new MoreInfoAbilitySlice(),intent);
    }

    private void setUI() {
        //将信息呈现至UI
        txt_ip.setText("ip:"+ip);
/*
        JSONObject sysJSONObject = new JSONObject(sys_data);
        String s_name = sysJSONObject.optString("hostname");

 */
        txt_server_name.setText(server_name);
        txt_CPU.setText("CPU:"+CPU+"%");
        txt_inner_mem.setText("MEM:"+mem+"%");

    }

    //listContainer在ProcessItemProvider 初始化后修改数据
    private void initListContainer() {
        ListContainer listContainer = (ListContainer) findComponentById(ResourceTable.Id_process_list_container);
        List<ProcessItem> list = getData();
        ProcessItemProvider processItemProvider = new ProcessItemProvider(list, this);
        listContainer.setItemProvider(processItemProvider);
        listContainer.setBindStateChangedListener(new Component.BindStateChangedListener() {
            @Override
            public void onComponentBoundToWindow(Component component) {
                // ListContainer初始化时数据统一在provider中创建，不直接调用这个接口；
                // 建议在onComponentBoundToWindow监听或者其他事件监听中调用。
                processItemProvider.notifyDataChanged();
            }

            @Override
            public void onComponentUnboundFromWindow(Component component) {}
        });
    }
    //添加ListContainer的数据,并适配其数据结构！！！！！！！！！！
    //由intent包含的process_Data对进程列表进行UI更新
    //
    private ArrayList<ProcessItem> getData() {
        ArrayList<ProcessItem> list = new ArrayList<>();
        List<Map> process_list = ZSONArray.stringToClassList(process_data, Map.class);
        int len = process_list.size();
        if(len==0){
            return null;
        }
        else {
            Map[] a = new Map[len];
            for (int i = 0; i < len; i++) {
                a[i] = process_list.get(i);
                list.add(new ProcessItem(
                        a[i].get("process_name").toString(),
                        a[i].get("cpu_percent").toString(),
                        a[i].get("memory_percent").toString())
                );
            }
            return list;
        }
    }
}
