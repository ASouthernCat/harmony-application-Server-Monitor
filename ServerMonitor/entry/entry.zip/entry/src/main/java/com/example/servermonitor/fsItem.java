package com.example.servermonitor;

public class fsItem {
    private String name;
    private String type;
    private String size;
    private String free;
    private String percent;

    public fsItem(String name,String type,String size,String free,String percent) {
        this.name = name;
        this.type = type;
        this.size = size;
        this.free = free;
        this.percent = percent;

    }
    public String getName() {
        return name;
    }
    public String getType() {
        return type;
    }
    public String getSize() {
        return size;
    }
    public String getFree() {
        return free;
    }
    public String getPercent() {
        return percent;
    }

    public void setName(String name) {
        this.name = name;
    }
}
