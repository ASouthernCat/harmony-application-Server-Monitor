package com.example.servermonitor.slice;

import com.example.servermonitor.ResourceTable;
import com.example.servermonitor.fsItem;
import com.example.servermonitor.provider.fsItemProvider;
import ohos.aafwk.ability.AbilitySlice;
import ohos.aafwk.content.Intent;
import ohos.agp.components.*;
import ohos.agp.utils.LayoutAlignment;
import ohos.utils.zson.ZSONArray;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class MoreInfoAbilitySlice extends AbilitySlice {
    Text txt_server_ip;
    Text txt_server_name;
    Text txt_os_name;
    Text txt_platform;
    String server_name,server_ip,os_name,platform,fs_json;

    public void onStart(Intent intent){
        super.onStart(intent);
        super.setUIContent(ResourceTable.Layout_more_info);
        //获取intent值
        if(intent!=null){
            server_name = intent.getStringParam("server_name");
            server_ip = intent.getStringParam("server_ip");
            os_name = intent.getStringParam("os_name");
            platform = intent.getStringParam("platform");
            fs_json  =intent.getStringParam("fs");  //还需进一步解析以呈现至UI
        }

        txt_server_name = (Text) findComponentById(ResourceTable.Id_txt_server_name);
        txt_server_ip = (Text) findComponentById(ResourceTable.Id_txt_server_ip);
        txt_os_name = (Text) findComponentById(ResourceTable.Id_txt_os_name);
        txt_platform = (Text) findComponentById(ResourceTable.Id_txt_platform) ;

        initListContainer();
        setUI();
    }

    private void setUI() {
        //将信息呈现至UI
        txt_server_ip.setText("ip地址："+server_ip);
        txt_server_name.setText("服务器名："+server_name);
        txt_os_name.setText("操作系统："+os_name);
        txt_platform.setText("系统位数："+platform);
    }

    //listContainer在ProcessItemProvider 初始化后修改数据
    private void initListContainer() {
        ListContainer listContainer = (ListContainer) findComponentById(ResourceTable.Id_fs_list_container);
        List<fsItem> list = getData();
        fsItemProvider fsItemProvider = new fsItemProvider(list, this);
        listContainer.setItemProvider(fsItemProvider);
        listContainer.setBindStateChangedListener(new Component.BindStateChangedListener() {
            @Override
            public void onComponentBoundToWindow(Component component) {
                // ListContainer初始化时数据统一在provider中创建，不直接调用这个接口；
                // 建议在onComponentBoundToWindow监听或者其他事件监听中调用。
                fsItemProvider.notifyDataChanged();
            }

            @Override
            public void onComponentUnboundFromWindow(Component component) {}
        });
    }

    private List<fsItem> getData() {
        ArrayList<fsItem> list = new ArrayList<>();
        List<Map> fs_list = ZSONArray.stringToClassList(fs_json, Map.class);
        int len = fs_list.size();
        if(len==0){
            return null;
        }
        else {
            Map[] a = new Map[len];
            for (int i = 0; i < len; i++) {
                a[i] = fs_list.get(i);
                list.add(new fsItem(
                        a[i].get("device_name").toString(),
                        a[i].get("fs_type").toString(),
                        a[i].get("size").toString()+"G",
                        a[i].get("free").toString()+"G",
                        a[i].get("percent").toString()+"%"
                        )
                );
            }
            return list;
        }
    }
}
