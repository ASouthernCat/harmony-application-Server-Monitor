package com.example.servermonitor.provider;

import com.example.servermonitor.ProcessItem;
import com.example.servermonitor.ResourceTable;
import ohos.aafwk.ability.AbilitySlice;
import ohos.agp.components.*;

import java.util.List;

public class ProcessItemProvider extends BaseItemProvider {
    private List<ProcessItem>list;
    private AbilitySlice slice;

    //构造函数
    public ProcessItemProvider(List<ProcessItem> list,AbilitySlice slice) {
        this.list = list;
        this.slice =slice;
    }

    @Override
    //返回填充的表项个数
    public int getCount() {
        return list == null ? 0 : list.size();
    }

    @Override
    //根据position返回对应的数据
    public Object getItem(int position) {
        if (list != null && position >= 0 && position < list.size()){
            return list.get(position);
        }
        return null;
    }

    @Override
    //返回某一项的id
    public long getItemId(int position) {
        //
        return position;
    }

    @Override
    //根据position返回对应的界面组件
    public Component getComponent(int position, Component convertComponent, ComponentContainer componentContainer) {
        final Component cpt;
        if (convertComponent == null) {
            cpt = LayoutScatter.getInstance(slice).parse(ResourceTable.Layout_item_process_list, null, false);
        } else {
            cpt = convertComponent;
        }
        ProcessItem processItem = list.get(position);
        Text item_process_name = (Text) cpt.findComponentById(ResourceTable.Id_item_process_name);
        Text item_process_CPU = (Text) cpt.findComponentById(ResourceTable.Id_item_process_cpu_percent);
        Text item_process_MEM = (Text) cpt.findComponentById(ResourceTable.Id_item_process_mem_percent);
        item_process_name.setText(processItem.getName());
        item_process_CPU.setText(processItem.getCPU());
        item_process_MEM.setText(processItem.getMEM());
        return cpt;
    }
}
