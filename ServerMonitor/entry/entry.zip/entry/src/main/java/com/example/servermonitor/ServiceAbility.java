package com.example.servermonitor;

import Constant.Constant;
import ohos.aafwk.ability.Ability;
import ohos.aafwk.content.Intent;
import ohos.rpc.*;
import ohos.hiviewdfx.HiLog;
import ohos.hiviewdfx.HiLogLabel;
import ohos.utils.zson.ZSONArray;
import ohos.utils.zson.ZSONObject;
import org.json.JSONObject;
import utils.JsonUtils;
import utils.NetDownLoadUtils;

import java.util.List;
import java.util.Map;

public class ServiceAbility extends Ability {
    private static final HiLogLabel LABEL_LOG = new HiLogLabel(3, 0x00201, "ServiceAbility");
    private MyRemote remote = new MyRemote();
    class MyRemote extends RemoteObject implements IRemoteBroker {

        MyRemote() {
            super("MyService_MyRemote");
            HiLog.info(LABEL_LOG, "MyRemote()----->");
        }

        // 设置接收请求的条目。
        // int code:表示从对等端发送的服务请求代码。
        @Override
        public boolean onRemoteRequest(int code, MessageParcel data, MessageParcel reply, MessageOption option) {
            HiLog.info(LABEL_LOG, "onRemoteRequest()----->");
            //获取MainAbilitySlice中请求传来的服务器IP
            String IP = data.readString();
            HiLog.info(LABEL_LOG, "onRemoteRequest---->" + code + ",--->IP:" + IP);

            //eg:
            // http://localhost:61208/api/3/cpu/total
            //http://localhost:61208/api/3/mem/percent
            //http://localhost:61208/api/3/system/hostname
            // http://localhost:61208/api/3/network
            //http://localhost:61208/api/3/processlist
            //https://api.openweathermap.org/data/2.5/forecast?&q=hengyang,CN&appid=accf59680d5b2039f92c468d4ac8e634

            //CPU百分比
            String cpu_url = "http://"+IP+":61208/api/3/cpu/total";   //CPU状态信息URL
            String cpu_Url = Constant.BASE_URI+"cpu:"+IP;
            HiLog.info(LABEL_LOG, "onRemoteRequest---->cpu_Url: "+cpu_Url);
            String cpuJSON = NetDownLoadUtils.downLoadServerData(cpu_Url); //下载json数据
            HiLog.info(LABEL_LOG,"cpu_json------>"+cpuJSON);
            if(cpuJSON==null)
                reply.writeInt(Constant.FAIL);
            JSONObject cpujSONObject = new JSONObject(cpuJSON);
            String cpuData = cpujSONObject.optString("total");



            //内存
            String mem_url = "http://"+IP+":61208/api/3/mem/percent";   //内存状态信息URL
            String mem_Url = Constant.BASE_URI+"mem:"+IP;
            HiLog.info(LABEL_LOG, "onRemoteRequest---->mem_Url: "+mem_Url);
            String memJSON = NetDownLoadUtils.downLoadServerData(mem_Url); //下载json数据
            HiLog.info(LABEL_LOG,"mem_json------>"+memJSON);

            JSONObject memjSONObject = new JSONObject(memJSON);
            String memData = memjSONObject.optString("percent");



            //文件系统
            String fs_url = Constant.BASE_URI+"fs:"+IP;
            HiLog.info(LABEL_LOG, "onRemoteRequest---->fs_Url: "+fs_url);
            String fsJSON = NetDownLoadUtils.downLoadServerData(fs_url); //下载 json数据
            HiLog.info(LABEL_LOG,"fs_json: "+fsJSON);
            List<Map<String, String>> fs_list = JsonUtils.parseFSJsonToList(fsJSON);
                    //"[{\"device_name\": \"C:\\\\\", \"fs_type\": \"NTFS\", \"mnt_point\": \"C:\\\\\", \"size\": 107374178304, \"used\": 87245492224, \"free\": 20128686080, \"percent\": 81.3, \"key\": \"mnt_point\"}, {\"device_name\": \"D:\\\\\", \"fs_type\": \"NTFS\", \"mnt_point\": \"D:\\\\\", \"size\": 296022437888, \"used\": 171398832128, \"free\": 124623605760, \"percent\": 57.9, \"key\": \"mnt_point\"}, {\"device_name\": \"E:\\\\\", \"fs_type\": \"NTFS\", \"mnt_point\": \"E:\\\\\", \"size\": 107373129728, \"used\": 56819363840, \"free\": 50553765888, \"percent\": 52.9, \"key\": \"mnt_point\"}]");//fsJSON);
            ZSONArray fs_array = new ZSONArray();
            // 将list集合转为ZSONArray集合
            for (int i = 0; i < fs_list.size(); i++) {
                fs_array.add(fs_list.get(i));
            }

            //system
            String sys_url = Constant.BASE_URI+"system:"+IP;
            HiLog.info(LABEL_LOG, "onRemoteRequest---->sys_Url: "+sys_url);
            String sysJSON = NetDownLoadUtils.downLoadServerData(sys_url); //下载json数据
            HiLog.info(LABEL_LOG,"sys_json："+sysJSON);

            JSONObject sysjSONObject = new JSONObject(sysJSON);
            String name = sysjSONObject.optString("hostname");


            //进程信息
            String process_url = "http://"+IP+":61208/api/3/processlist";   //进程状态信息URL
            String process_Url = Constant.BASE_URI+"processlist:"+IP;   //进程状态信息URL
            HiLog.info(LABEL_LOG, "onRemoteRequest---->process_Url: "+process_Url);
            String processJSON = NetDownLoadUtils.downLoadServerData(process_Url); //下载json数据
            HiLog.info(LABEL_LOG,"process_json------>"+processJSON);
            //........解析进程信息的JSON数据...........
            List<Map<String, String>> list = JsonUtils.parseProcessJsonToList(processJSON);
            HiLog.info(LABEL_LOG,"process_json---> list: --->"+list);
            ZSONArray array = new ZSONArray();
            // 将list集合转为ZSONArray集合
            for (int i = 0; i < list.size(); i++) {
                array.add(list.get(i));
            }
            HiLog.info(LABEL_LOG, "onRemoteRequest--->process--->array-->" + array);

            //传回数据 reply
            if(cpuJSON==null)
            reply.writeInt(Constant.FAIL);
            else reply.writeInt(Constant.SUCCESS);
            /*
            reply.writeString("16.9%");   //测试 cpu。。。。。。。。。。。。。。。。
            reply.writeString("23%");     //测试 内存
            reply.writeString(ZSONObject.toZSONString(array));   //进程信息
            reply.writeString("{\"os_name\": \"Windows\", \"hostname\": \"LAPTOP-MS25DMBO\", \"platform\": \"64bit\", \"os_version\": \"10 SP0\", \"hr_name\": \"Windows 10 SP0 64bit\"}");  //system
            reply.writeString(ZSONObject.toZSONString(fs_array)); //fs
*/
            reply.writeString(cpuData);
            reply.writeString(memData);
            reply.writeString(ZSONObject.toZSONString(array));
            reply.writeString(sysJSON);  //system
            reply.writeString(ZSONObject.toZSONString(fs_array)); //fs

            return true;
        }

        @Override
        public IRemoteObject asObject() {
            return this;
        }
    }

    @Override
    public void onStart(Intent intent) {
        HiLog.error(LABEL_LOG, "ServiceAbility::onStart");
        super.onStart(intent);
    }

    @Override
    public void onBackground() {
        super.onBackground();
        HiLog.info(LABEL_LOG, "ServiceAbility::onBackground");
    }

    @Override
    public void onStop() {
        super.onStop();
        HiLog.info(LABEL_LOG, "ServiceAbility::onStop");
    }

    @Override
    public void onCommand(Intent intent, boolean restart, int startId) {
    }

    @Override
    public IRemoteObject onConnect(Intent intent) {
        super.onConnect(intent);

        HiLog.info(LABEL_LOG, "onConnect()---->");
        return remote.asObject();
    }

    @Override
    public void onDisconnect(Intent intent) {
    }
}