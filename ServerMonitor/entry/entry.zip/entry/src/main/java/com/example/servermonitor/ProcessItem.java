package com.example.servermonitor;
//ListContainer的数据包装类
public class ProcessItem {
    private String name;
    private String CPU;
    private String MEM;

    public ProcessItem(String name,String cpu,String mem) {
        this.name = name;
        this.CPU = cpu;
        this.MEM = mem;
    }
    public String getName() {
        return name;
    }
    public String getCPU() {
        return CPU;
    }
    public String getMEM() {
        return MEM;
    }

    public void setName(String name) {
        this.name = name;
    }
}
