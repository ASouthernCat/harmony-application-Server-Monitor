package Constant;

public class Constant {
    public static final int SUCCESS = 1;

    public static final int FAIL = 0 ;

    //http://qebhps.natappfree.cc/processlist:10.8.109.151
    public static final String BASE_URI = "http://p4ch2d.natappfree.cc/";
}
