package utils;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class JsonUtils {
    public static List<Map<String,String>> parseProcessJsonToList(String json){
        List<Map<String,String>> list = new ArrayList<>();
        if(json==null|| "".equals(json)){
            return list;
        }
        try {
            JSONArray jsonArray = new JSONArray(json);  //json队列
            for(int i=0;i<20;i++){     //遍历进程信息,取20条  jsonArray.length()
                JSONObject jSONObject = jsonArray.getJSONObject(i);
                Map<String,String> map = new HashMap<>();
                map.put("process_name",jSONObject.optString("name"));  //进程名
                map.put("cpu_percent",String.format("%.2f",jSONObject.optDouble("cpu_percent"))); //CPU占用率
                map.put("memory_percent",String.format("%.2f",jSONObject.optDouble("memory_percent"))); //内存占用率
                list.add(map);
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return list;
    }
    public static List<Map<String,String>> parseFSJsonToList(String json){
        List<Map<String,String>> list = new ArrayList<>();
        if(json==null|| "".equals(json)){
            return list;
        }
        try {
            JSONArray jsonArray = new JSONArray(json);  //json队列
            for(int i=0;i< jsonArray.length();i++){
                JSONObject jSONObject = jsonArray.getJSONObject(i);
                Map<String,String> map = new HashMap<>();
                map.put("device_name",jSONObject.optString("device_name"));  //分区名
                map.put("fs_type",jSONObject.optString("fs_type"));  //文件系统类型
                map.put("size",String.format("%.1f",jSONObject.optDouble("size")/(1024*1024*1024))); //总空间
                map.put("free",String.format("%.1f",jSONObject.optDouble("free")/(1024*1024*1024))); //可用空间
                map.put("percent",String.format("%.1f",jSONObject.optDouble("percent"))); //空间使用率
                list.add(map);
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return list;
    }

}
