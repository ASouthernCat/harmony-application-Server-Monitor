package utils;

import ohos.hiviewdfx.HiLog;

public class concatURL {
    // 拼接URL
    public String concatUrl(String link, String params[]) {
        StringBuilder urlFinal = new StringBuilder();
        urlFinal.append(link);
        urlFinal.append("?");
        for (int i = 0; i < params.length; i++) {
            urlFinal.append("&");
            urlFinal.append(params[i]);

        }
        return urlFinal.toString();
    }
}
